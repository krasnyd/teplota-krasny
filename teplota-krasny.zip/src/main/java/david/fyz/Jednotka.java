package david.fyz;

public enum Jednotka {
    CELSIUS,
    FAHRENHEIT,
    KELVIN
}
